#!/usr/bin/env python3
import argparse, os, json, gzip
from collections import defaultdict

def parse_reviews_gz(path):
    users = defaultdict(list)
    with gzip.open(path, 'rt', encoding='utf-8') as f:
        for line in f:
            try:
                r = json.loads(line)
            except:
                continue
            if not {'reviewerID','asin','unixReviewTime'} <= r.keys():
                continue
            uid = r['reviewerID']; iid = r['asin']; ts = int(r['unixReviewTime'])
            users[uid].append((ts, iid))
    return users

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--in_file', required=True, help='path to reviews json.gz (All_Beauty.json.gz or Sports_and_Outdoors.json.gz)')
    ap.add_argument('--out_dir', required=True, help='output folder')
    args = ap.parse_args()
    os.makedirs(args.out_dir, exist_ok=True)

    users = parse_reviews_gz(args.in_file)
    item_map = {}
    def iid(x):
        if x not in item_map:
            item_map[x] = len(item_map)+1
        return item_map[x]

    tr = open(os.path.join(args.out_dir, 'train.jsonl'), 'w', encoding='utf-8')
    va = open(os.path.join(args.out_dir, 'val.jsonl'), 'w', encoding='utf-8')
    te = open(os.path.join(args.out_dir, 'test.jsonl'), 'w', encoding='utf-8')
    ntr=nva=nte=0
    for u, ev in users.items():
        ev.sort()
        items = [iid(a) for _, a in ev]
        if len(items) < 3: 
            continue
        for i in range(1, len(items)-1):
            tr.write(json.dumps({"user": u, "seq": items[:i], "target": items[i]}, ensure_ascii=False)+'\n'); ntr+=1
        va.write(json.dumps({"user": u, "seq": items[:-2], "target": items[-2]}, ensure_ascii=False)+'\n'); nva+=1
        te.write(json.dumps({"user": u, "seq": items[:-1], "target": items[-1]}, ensure_ascii=False)+'\n'); nte+=1
    tr.close(); va.close(); te.close()

    meta = {"num_users": len(users), "num_items": len(item_map)}
    with open(os.path.join(args.out_dir, 'meta.json'), 'w', encoding='utf-8') as fp:
        json.dump(meta, fp, ensure_ascii=False, indent=2)
    print(f"Done. train={ntr}, val={nva}, test={nte}, num_items={len(item_map)}")

if __name__ == '__main__':
    main()
